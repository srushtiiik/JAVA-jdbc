/*import java.awt.*;
import java.sql.*;
import java.util.*;
import javax.swing.*;

public class MainFrame extends JFrame {
    JComboBox<String> tableBox, columnBox, collectionBox;
    JTextArea resultArea;
    JButton fetchBtn;

    public MainFrame() {
        // Frame properties
        setTitle("Swing DB Viewer");
        setSize(800, 500);
        setDefaultCloseOperation(EXIT_ON_CLOSE);
        setLocationRelativeTo(null);

        // Initialize components
        JPanel panel = new JPanel();
        panel.setLayout(new BoxLayout(panel, BoxLayout.Y_AXIS));
        panel.setBorder(BorderFactory.createEmptyBorder(20, 20, 20, 20));
        setContentPane(panel);

        // Title Label
        JLabel titleLabel = new JLabel("Database Viewer");
        titleLabel.setFont(new Font("Arial", Font.BOLD, 30));
        titleLabel.setForeground(new Color(0, 123, 255));
        titleLabel.setAlignmentX(Component.CENTER_ALIGNMENT);
        panel.add(titleLabel);

        // Table and Column Selection Panel
        JPanel tableColumnPanel = new JPanel();
        tableColumnPanel.setLayout(new FlowLayout(FlowLayout.LEFT));
        panel.add(tableColumnPanel);

        // Table selection
        JLabel tableLabel = new JLabel("Select Table:");
        tableLabel.setFont(new Font("Arial", Font.PLAIN, 16));
        tableBox = new JComboBox<>(new String[]{"students", "employees"});
        tableBox.setFont(new Font("Arial", Font.PLAIN, 16));
        tableBox.addActionListener(e -> loadColumns());
        tableColumnPanel.add(tableLabel);
        tableColumnPanel.add(tableBox);

        // Column selection
        JLabel columnLabel = new JLabel("Select Column:");
        columnLabel.setFont(new Font("Arial", Font.PLAIN, 16));
        columnBox = new JComboBox<>();
        columnBox.setFont(new Font("Arial", Font.PLAIN, 16));
        tableColumnPanel.add(columnLabel);
        tableColumnPanel.add(columnBox);

        // Collection selection
        JLabel collectionLabel = new JLabel("Select Collection:");
        collectionLabel.setFont(new Font("Arial", Font.PLAIN, 16));
        collectionBox = new JComboBox<>(new String[]{"ArrayList", "LinkedList", "HashSet"});
        collectionBox.setFont(new Font("Arial", Font.PLAIN, 16));
        tableColumnPanel.add(collectionLabel);
        tableColumnPanel.add(collectionBox);

        // Fetch Data Button
        fetchBtn = new JButton("Fetch Data");
        fetchBtn.setFont(new Font("Arial", Font.BOLD, 16));
        fetchBtn.setBackground(new Color(0, 123, 255));
        fetchBtn.setForeground(Color.WHITE);
        fetchBtn.setFocusPainted(false);
        fetchBtn.setPreferredSize(new Dimension(180, 40));
        fetchBtn.addActionListener(e -> fetchData());
        fetchBtn.setAlignmentX(Component.CENTER_ALIGNMENT);
        panel.add(fetchBtn);

        // Result area to display data
        resultArea = new JTextArea(15, 55);
        resultArea.setFont(new Font("Arial", Font.PLAIN, 14));
        resultArea.setEditable(false);
        resultArea.setLineWrap(true);
        resultArea.setWrapStyleWord(true);
        resultArea.setBackground(new Color(245, 245, 245));
        resultArea.setForeground(new Color(40, 40, 40));

        JScrollPane scrollPane = new JScrollPane(resultArea);
        scrollPane.setPreferredSize(new Dimension(750, 200));
        panel.add(scrollPane);

        // Initial column loading based on selected table
        loadColumns();

        setVisible(true);
    }

    private void loadColumns() {
        columnBox.removeAllItems();
        String table = (String) tableBox.getSelectedItem();
        try (Connection con = DBConnection.getConnection()) {
            DatabaseMetaData meta = con.getMetaData();
            ResultSet rs = meta.getColumns(null, null, table, null);
            while (rs.next()) {
                columnBox.addItem(rs.getString("COLUMN_NAME"));
            }
            // Set default column for the first table
            if (columnBox.getItemCount() > 0) {
                columnBox.setSelectedIndex(0);
            }
        } catch (Exception ex) {
            resultArea.setText("Error loading columns: " + ex.getMessage());
        }
    }

    private void fetchData() {
        String table = (String) tableBox.getSelectedItem();
        String column = (String) columnBox.getSelectedItem();
        String collection = (String) collectionBox.getSelectedItem();

        // Choosing collection type based on user selection
        Collection<Object> data;

        switch (collection) {
            case "ArrayList":
                data = new ArrayList<>();
                break;
            case "LinkedList":
                data = new LinkedList<>();
                break;
            case "HashSet":
                data = new HashSet<>();
                break;
            default:
                data = new ArrayList<>();
        }

        try (Connection con = DBConnection.getConnection()) {
            Statement st = con.createStatement();
            ResultSet rs = st.executeQuery("SELECT " + column + " FROM " + table);
            while (rs.next()) {
                data.add(rs.getObject(1)); // Generics used here
            }

            // Sort the data if it's a List and elements are Comparable
            if (data instanceof java.util.List) {
                java.util.List<Object> list = new ArrayList<>(data);
                list.sort(new GenericComparator()); // custom comparator
                data = list;
            }

            // Clear result and display
            resultArea.setText("Fetched Data:\n");

            // Use Iterator to display data
            Iterator<Object> iterator = data.iterator();
            if (iterator.hasNext()) {
                resultArea.append(iterator.next().toString() + "\n"); // First item printed by Iterator
            }

            // Use for-each loop to print the rest of the data
            boolean isFirstItemPrinted = false;
            for (Object item : data) {
                // Skip the first element if already printed by Iterator
                if (!isFirstItemPrinted) {
                    isFirstItemPrinted = true;  // Mark that the first item has been printed
                    continue;  // Skip printing the first item again in the for-each loop
                }
                resultArea.append(item.toString() + "\n");  // Print remaining items
            }

        } catch (Exception ex) {
            resultArea.setText("Error fetching data: " + ex.getMessage());
        }
    }

    // Generic comparator to sort the list
    class GenericComparator<T extends Comparable<T>> implements Comparator<T> {
        public int compare(T a, T b) {
            return a.compareTo(b);
        }
    }

    public static void main(String[] args) {
        new MainFrame();
    }
}
*/

import java.awt.*;
import java.sql.*;
import java.util.*;
import javax.swing.*;

public class MainFrame extends JFrame {
    JComboBox<String> tableBox, columnBox, collectionBox;
    JTextArea resultArea;
    JButton fetchBtn, insertBtn;
    JTextField[] inputFields;
    JPanel inputPanel;

    public MainFrame() {
        setTitle("Swing DB Viewer with Insert");
        setSize(900, 600);
        setDefaultCloseOperation(EXIT_ON_CLOSE);
        setLocationRelativeTo(null);

        JPanel panel = new JPanel();
        panel.setLayout(new BoxLayout(panel, BoxLayout.Y_AXIS));
        panel.setBorder(BorderFactory.createEmptyBorder(20, 20, 20, 20));
        setContentPane(panel);

        JLabel titleLabel = new JLabel("Database Viewer & Inserter");
        titleLabel.setFont(new Font("Arial", Font.BOLD, 30));
        titleLabel.setForeground(new Color(0, 123, 255));
        titleLabel.setAlignmentX(Component.CENTER_ALIGNMENT);
        panel.add(titleLabel);

        JPanel tableColumnPanel = new JPanel();
        tableColumnPanel.setLayout(new FlowLayout(FlowLayout.LEFT));
        panel.add(tableColumnPanel);

        JLabel tableLabel = new JLabel("Select Table:");
        tableLabel.setFont(new Font("Arial", Font.PLAIN, 16));
        tableBox = new JComboBox<>(new String[]{"students", "employees"});
        tableBox.setFont(new Font("Arial", Font.PLAIN, 16));
        tableBox.addActionListener(e -> {
            loadColumns();
            showInsertFields();
        });
        tableColumnPanel.add(tableLabel);
        tableColumnPanel.add(tableBox);

        JLabel columnLabel = new JLabel("Select Column:");
        columnLabel.setFont(new Font("Arial", Font.PLAIN, 16));
        columnBox = new JComboBox<>();
        columnBox.setFont(new Font("Arial", Font.PLAIN, 16));
        tableColumnPanel.add(columnLabel);
        tableColumnPanel.add(columnBox);

        JLabel collectionLabel = new JLabel("Select Collection:");
        collectionLabel.setFont(new Font("Arial", Font.PLAIN, 16));
        collectionBox = new JComboBox<>(new String[]{"ArrayList", "LinkedList", "HashSet"});
        collectionBox.setFont(new Font("Arial", Font.PLAIN, 16));
        tableColumnPanel.add(collectionLabel);
        tableColumnPanel.add(collectionBox);

        fetchBtn = new JButton("Fetch Data");
        fetchBtn.setFont(new Font("Arial", Font.BOLD, 16));
        fetchBtn.setBackground(new Color(0, 123, 255));
        fetchBtn.setForeground(Color.WHITE);
        fetchBtn.setFocusPainted(false);
        fetchBtn.setPreferredSize(new Dimension(180, 40));
        fetchBtn.addActionListener(e -> fetchData());
        fetchBtn.setAlignmentX(Component.CENTER_ALIGNMENT);
        panel.add(fetchBtn);

        // Insert panel
        inputPanel = new JPanel();
        inputPanel.setLayout(new BoxLayout(inputPanel, BoxLayout.Y_AXIS));
        panel.add(inputPanel);
        showInsertFields();

        insertBtn = new JButton("Insert Data");
        insertBtn.setFont(new Font("Arial", Font.BOLD, 16));
        insertBtn.setBackground(new Color(40, 167, 69));
        insertBtn.setForeground(Color.WHITE);
        insertBtn.setFocusPainted(false);
        insertBtn.setPreferredSize(new Dimension(180, 40));
        insertBtn.setAlignmentX(Component.CENTER_ALIGNMENT);
        insertBtn.addActionListener(e -> insertData());
        panel.add(insertBtn);

        resultArea = new JTextArea(15, 55);
        resultArea.setFont(new Font("Arial", Font.PLAIN, 14));
        resultArea.setEditable(false);
        resultArea.setLineWrap(true);
        resultArea.setWrapStyleWord(true);
        resultArea.setBackground(new Color(245, 245, 245));
        resultArea.setForeground(new Color(40, 40, 40));

        JScrollPane scrollPane = new JScrollPane(resultArea);
        scrollPane.setPreferredSize(new Dimension(850, 200));
        panel.add(scrollPane);

        loadColumns();
        setVisible(true);
    }

    private void loadColumns() {
        columnBox.removeAllItems();
        String table = (String) tableBox.getSelectedItem();
        try (Connection con = DBConnection.getConnection()) {
            DatabaseMetaData meta = con.getMetaData();
            ResultSet rs = meta.getColumns(null, null, table, null);
            while (rs.next()) {
                columnBox.addItem(rs.getString("COLUMN_NAME"));
            }
            if (columnBox.getItemCount() > 0) {
                columnBox.setSelectedIndex(0);
            }
        } catch (Exception ex) {
            resultArea.setText("Error loading columns: " + ex.getMessage());
        }
    }

    private void fetchData() {
        String table = (String) tableBox.getSelectedItem();
        String column = (String) columnBox.getSelectedItem();
        String collection = (String) collectionBox.getSelectedItem();

        Collection<Object> data;

        switch (collection) {
            case "ArrayList":
                data = new ArrayList<>();
                break;
            case "LinkedList":
                data = new LinkedList<>();
                break;
            case "HashSet":
                data = new HashSet<>();
                break;
            default:
                data = new ArrayList<>();
        }

        try (Connection con = DBConnection.getConnection()) {
            Statement st = con.createStatement();
            ResultSet rs = st.executeQuery("SELECT " + column + " FROM " + table);
            while (rs.next()) {
                data.add(rs.getObject(1));
            }

            if (data instanceof java.util.List) {
                java.util.List<Object> list = new ArrayList<>(data);
                list.sort(new GenericComparator());
                data = list;
            }

            resultArea.setText("Fetched Data:\n");

            Iterator<Object> iterator = data.iterator();
            if (iterator.hasNext()) {
                resultArea.append(iterator.next().toString() + "\n");
            }

            boolean isFirstItemPrinted = false;
            for (Object item : data) {
                if (!isFirstItemPrinted) {
                    isFirstItemPrinted = true;
                    continue;
                }
                resultArea.append(item.toString() + "\n");
            }

        } catch (Exception ex) {
            resultArea.setText("Error fetching data: " + ex.getMessage());
        }
    }

    private void showInsertFields() {
        inputPanel.removeAll();
        String table = (String) tableBox.getSelectedItem();
        if (table.equals("students")) {
            String[] labels = {"ID", "Name", "Marks", "Grade", "Passed (true/false)"};
            inputFields = new JTextField[labels.length];
            for (int i = 0; i < labels.length; i++) {
                JPanel row = new JPanel(new FlowLayout(FlowLayout.LEFT));
                JLabel lbl = new JLabel(labels[i] + ": ");
                inputFields[i] = new JTextField(15);
                row.add(lbl);
                row.add(inputFields[i]);
                inputPanel.add(row);
            }
        } else if (table.equals("employees")) {
            String[] labels = {"Emp ID", "Emp Name", "Salary", "Grade", "Is Permanent (true/false)"};
            inputFields = new JTextField[labels.length];
            for (int i = 0; i < labels.length; i++) {
                JPanel row = new JPanel(new FlowLayout(FlowLayout.LEFT));
                JLabel lbl = new JLabel(labels[i] + ": ");
                inputFields[i] = new JTextField(15);
                row.add(lbl);
                row.add(inputFields[i]);
                inputPanel.add(row);
            }
        }
        inputPanel.revalidate();
        inputPanel.repaint();
    }

    private void insertData() {
        String table = (String) tableBox.getSelectedItem();

        try (Connection con = DBConnection.getConnection()) {
            String sql;
            PreparedStatement ps;
            if (table.equals("students")) {
                sql = "INSERT INTO students VALUES (?, ?, ?, ?, ?)";
                ps = con.prepareStatement(sql);
                ps.setInt(1, Integer.parseInt(inputFields[0].getText()));
                ps.setString(2, inputFields[1].getText());
                ps.setFloat(3, Float.parseFloat(inputFields[2].getText()));
                ps.setString(4, inputFields[3].getText());
                ps.setBoolean(5, Boolean.parseBoolean(inputFields[4].getText()));
            } else {
                sql = "INSERT INTO employees VALUES (?, ?, ?, ?, ?)";
                ps = con.prepareStatement(sql);
                ps.setInt(1, Integer.parseInt(inputFields[0].getText()));
                ps.setString(2, inputFields[1].getText());
                ps.setFloat(3, Float.parseFloat(inputFields[2].getText()));
                ps.setString(4, inputFields[3].getText());
                ps.setBoolean(5, Boolean.parseBoolean(inputFields[4].getText()));
            }
            ps.executeUpdate();
            resultArea.setText("Data inserted successfully into " + table);
        } catch (Exception ex) {
            resultArea.setText("Error inserting data: " + ex.getMessage());
        }
    }

    // Updated non-generic comparator
    class GenericComparator implements Comparator<Object> {
        public int compare(Object a, Object b) {
            if (a instanceof Comparable && b instanceof Comparable) {
                return ((Comparable<Object>) a).compareTo(b);
            }
            return 0;
        }
    }

    public static void main(String[] args) {
        new MainFrame();
    }
}


/*
import java.awt.*;
import java.sql.*;
import java.util.*;
import javax.swing.*;

public class MainFrame extends JFrame {
    JComboBox<String> tableBox, columnBox, collectionBox;
    JTextArea resultArea;
    JButton fetchBtn;

    public MainFrame() {
        // Frame properties
        setTitle("Swing DB Viewer");
        setSize(800, 500);
        setDefaultCloseOperation(EXIT_ON_CLOSE);
        setLocationRelativeTo(null);

        // Initialize components
        JPanel panel = new JPanel();
        panel.setLayout(new BoxLayout(panel, BoxLayout.Y_AXIS));
        panel.setBorder(BorderFactory.createEmptyBorder(20, 20, 20, 20));
        setContentPane(panel);

        // Title Label
        JLabel titleLabel = new JLabel("Database Viewer");
        titleLabel.setFont(new Font("Arial", Font.BOLD, 30));
        titleLabel.setForeground(new Color(0, 123, 255));
        titleLabel.setAlignmentX(Component.CENTER_ALIGNMENT);
        panel.add(titleLabel);

        // Table and Column Selection Panel
        JPanel tableColumnPanel = new JPanel();
        tableColumnPanel.setLayout(new FlowLayout(FlowLayout.LEFT));
        panel.add(tableColumnPanel);

        // Table selection
        JLabel tableLabel = new JLabel("Select Table:");
        tableLabel.setFont(new Font("Arial", Font.PLAIN, 16));
        tableBox = new JComboBox<>(new String[]{"students", "employees"});
        tableBox.setFont(new Font("Arial", Font.PLAIN, 16));
        tableBox.addActionListener(e -> loadColumns());
        tableColumnPanel.add(tableLabel);
        tableColumnPanel.add(tableBox);

        // Column selection
        JLabel columnLabel = new JLabel("Select Column:");
        columnLabel.setFont(new Font("Arial", Font.PLAIN, 16));
        columnBox = new JComboBox<>();
        columnBox.setFont(new Font("Arial", Font.PLAIN, 16));
        tableColumnPanel.add(columnLabel);
        tableColumnPanel.add(columnBox);

        // Collection selection
        JLabel collectionLabel = new JLabel("Select Collection:");
        collectionLabel.setFont(new Font("Arial", Font.PLAIN, 16));
        collectionBox = new JComboBox<>(new String[]{"ArrayList", "LinkedList", "HashSet"});
        collectionBox.setFont(new Font("Arial", Font.PLAIN, 16));
        tableColumnPanel.add(collectionLabel);
        tableColumnPanel.add(collectionBox);

        // Fetch Data Button
        fetchBtn = new JButton("Fetch Data");
        fetchBtn.setFont(new Font("Arial", Font.BOLD, 16));
        fetchBtn.setBackground(new Color(0, 123, 255));
        fetchBtn.setForeground(Color.WHITE);
        fetchBtn.setFocusPainted(false);
        fetchBtn.setPreferredSize(new Dimension(180, 40));
        fetchBtn.addActionListener(e -> fetchData());
        fetchBtn.setAlignmentX(Component.CENTER_ALIGNMENT);
        panel.add(fetchBtn);

        // Result area to display data
        resultArea = new JTextArea(15, 55);
        resultArea.setFont(new Font("Arial", Font.PLAIN, 14));
        resultArea.setEditable(false);
        resultArea.setLineWrap(true);
        resultArea.setWrapStyleWord(true);
        resultArea.setBackground(new Color(245, 245, 245));
        resultArea.setForeground(new Color(40, 40, 40));

        JScrollPane scrollPane = new JScrollPane(resultArea);
        scrollPane.setPreferredSize(new Dimension(750, 200));
        panel.add(scrollPane);

        // Initial column loading based on selected table
        loadColumns();

        setVisible(true);
    }

    private void loadColumns() {
        columnBox.removeAllItems();
        String table = (String) tableBox.getSelectedItem();
        try (Connection con = DBConnection.getConnection()) {
            DatabaseMetaData meta = con.getMetaData();
            ResultSet rs = meta.getColumns(null, null, table, null);
            while (rs.next()) {
                columnBox.addItem(rs.getString("COLUMN_NAME"));
            }
            // Set default column for the first table
            if (columnBox.getItemCount() > 0) {
                columnBox.setSelectedIndex(0);
            }
        } catch (Exception ex) {
            resultArea.setText("Error loading columns: " + ex.getMessage());
        }
    }

    private void fetchData() {
        String table = (String) tableBox.getSelectedItem();
        String column = (String) columnBox.getSelectedItem();
        String collection = (String) collectionBox.getSelectedItem();

        // Choosing collection type based on user selection
        Collection<Object> data;

        switch (collection) {
            case "ArrayList": 
                data = new ArrayList<>(); 
                break;
            case "LinkedList": 
                data = new LinkedList<>(); 
                break;
            case "HashSet": 
                data = new HashSet<>(); 
                break;
            default: 
                data = new ArrayList<>();
        }

        try (Connection con = DBConnection.getConnection()) {
            Statement st = con.createStatement();
            ResultSet rs = st.executeQuery("SELECT " + column + " FROM " + table);
            while (rs.next()) {
                data.add(rs.getObject(1)); // Generics used here
            }

            if (data instanceof java.util.List && !data.isEmpty() && data.iterator().next() instanceof Comparable) {
                java.util.List<Object> list = new java.util.ArrayList<>(data);
                list.sort(new GenericComparator());
                data = list;
            }

            // Display results
            if (data.isEmpty()) {
                resultArea.setText("No data found.");
            } else {
                resultArea.setText("Data:\n");
                for (Object item : data) {
                    resultArea.append(item.toString() + "\n");
                }
            }

        } catch (Exception ex) {
            resultArea.setText("Error fetching data: " + ex.getMessage());
        }
    }

    // Generic comparator to sort the list
    class GenericComparator<T extends Comparable<T>> implements Comparator<T> {
        public int compare(T a, T b) {
            return a.compareTo(b);
        }
    }

    public static void main(String[] args) {
        new MainFrame();
    }
}
 */


 /*
import java.awt.*;
import java.sql.*;
import java.util.*;
import javax.swing.*;

public class MainFrame extends JFrame {
    JComboBox<String> tableBox, columnBox, collectionBox;
    JTextArea resultArea;
    JButton fetchBtn;

    public MainFrame() {
        setTitle("Swing DB Viewer");
        setSize(700, 400);
        setLayout(new FlowLayout());

        // Initialize components
        tableBox = new JComboBox<>(new String[]{"students", "employees"});
        columnBox = new JComboBox<>();
        collectionBox = new JComboBox<>(new String[]{"ArrayList", "LinkedList", "HashSet"});
        fetchBtn = new JButton("Fetch Data");
        resultArea = new JTextArea(15, 55);
        resultArea.setEditable(false);

        // Add components to frame
        add(new JLabel("Select Table:")); 
        add(tableBox);
        add(new JLabel("Select Column:")); 
        add(columnBox);
        add(new JLabel("Select Collection:")); 
        add(collectionBox);
        add(fetchBtn);
        add(new JScrollPane(resultArea));

        // Event listeners
        tableBox.addActionListener(e -> loadColumns());
        fetchBtn.addActionListener(e -> fetchData());

        loadColumns();

        // Window settings
        setDefaultCloseOperation(EXIT_ON_CLOSE);
        setVisible(true);
    }

    private void loadColumns() {
        columnBox.removeAllItems();
        String table = (String) tableBox.getSelectedItem();
        try (Connection con = DBConnection.getConnection()) {
            DatabaseMetaData meta = con.getMetaData();
            ResultSet rs = meta.getColumns(null, null, table, null);
            while (rs.next()) {
                columnBox.addItem(rs.getString("COLUMN_NAME"));
            }
            // Set default column for the first table
            if (columnBox.getItemCount() > 0) {
                columnBox.setSelectedIndex(0);
            }
        } catch (Exception ex) {
            resultArea.setText("Error loading columns: " + ex.getMessage());
        }
    }

    private void fetchData() {
        String table = (String) tableBox.getSelectedItem();
        String column = (String) columnBox.getSelectedItem();
        String collection = (String) collectionBox.getSelectedItem();

        Collection<Object> data;

        switch (collection) {
            case "ArrayList": data = new ArrayList<>(); break;
            case "LinkedList": data = new LinkedList<>(); break;
            case "HashSet": data = new HashSet<>(); break;
            default: data = new ArrayList<>();
        }

        try (Connection con = DBConnection.getConnection()) {
            Statement st = con.createStatement();
            ResultSet rs = st.executeQuery("SELECT " + column + " FROM " + table);
            while (rs.next()) {
                data.add(rs.getObject(1)); // Generics used here
            }

            if (data instanceof java.util.List && !data.isEmpty() && data.iterator().next() instanceof Comparable) {
                java.util.List<Object> list = new java.util.ArrayList<>(data);
                list.sort(new GenericComparator());
                data = list;
            }

            // Display results
            if (data.isEmpty()) {
                resultArea.setText("No data found.");
            } else {
                resultArea.setText("Data:\n");
                for (Object item : data) {
                    resultArea.append(item.toString() + "\n");
                }
            }

        } catch (Exception ex) {
            resultArea.setText("Error fetching data: " + ex.getMessage());
        }
    }

    // Generic comparator to sort the list
    class GenericComparator<T extends Comparable<T>> implements Comparator<T> {
        public int compare(T a, T b) {
            return a.compareTo(b);
        }
    }

    public static void main(String[] args) {
        new MainFrame();
    }
}
  */